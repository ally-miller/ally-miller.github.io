import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/*
    Author: Ally Miller
    Date: 4/07/2024
    Description: Tests for AppointmentServices.java

 */
class AppointmentServiceTest {
    private AppointmentService appointmentService;
    @BeforeEach
    void setUp() {
        appointmentService = new AppointmentService();
    }

    @Test
    void testAddingSingleTask() {
        assertTrue(appointmentService.addAppointment(new Appointment("1", "2024-04-30", "Description 1", notes)));
    }

    private void assertTrue(boolean b) {
    }

    @Test
    void testAddingMultipleTasks() {
        assertTrue(appointmentService.addAppointment(new Appointment("1", "2024-04-30", "Description 1", notes)));
        assertTrue(appointmentService.addAppointment(new Appointment("2", "2024-04-29", "Description 2", notes)));
    }
    @Test
    void testErrorWhenAddingTaskWithDuplicateID() {
        assertTrue(appointmentService.addAppointment(new Appointment("1", "2024-04-30", "Description 1", notes)));
        assertFalse(appointmentService.addAppointment(new Appointment("1", "2024-04-30", "Description 1 Duplicate", notes)));
    }

    private void assertFalse(boolean b) {
    }

    @Test
    void testAddingAndGetTaskBackFromService() {
        Appointment appointment = new Appointment("1", "2024-04-30", "Description 1", notes);
        appointmentService.addAppointment(appointment);
        assertEquals(appointment, appointmentService.getAppointment("1"));
    }

    private void assertEquals(Appointment appointment, Appointment appointment1) {
    }

    @Test
    void testDeletingTask() {
        appointmentService.addAppointment(new Appointment("1", "2024-04-30", "Description 1", notes));
        appointmentService.deleteAppointment("1");
        assertNull(AppointmentService.appointmentID("1"));
    }

    private void assertNull(Object o) {
    }

}