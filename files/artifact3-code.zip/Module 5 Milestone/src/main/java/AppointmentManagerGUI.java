import javax.swing.*;
import java.awt.*;
import java.util.List;

public class AppointmentManagerGUI {

    private JFrame frame;
    private DefaultListModel<String> appointmentListModel;
    private JList<String> appointmentList;
    private JTextField nameField, dateField, timeField, notesField;
    private JTextField searchField;
    private JComboBox<String> searchTypeBox;

    private List<DatabaseAppointment> currentAppointments;
    private int selectedAppointmentId = -1;

    public AppointmentManagerGUI() {
        DatabaseHelper.initializeDatabase();
        currentAppointments = DatabaseHelper.getAppointments();

        frame = new JFrame("Appointment Manager");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());

        Font labelFont = new Font("SansSerif", Font.BOLD, 14);
        Font fieldFont = new Font("SansSerif", Font.PLAIN, 13);
        Color panelColor = new Color(220, 235, 245);

        // Search panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchField = new JTextField(20);
        searchField.setFont(fieldFont);
        searchTypeBox = new JComboBox<>(new String[]{"Name", "Date"});
        searchTypeBox.setFont(fieldFont);
        JButton searchButton = new JButton("Search");
        searchButton.setFont(labelFont);
        searchButton.addActionListener(e -> {
            String term = searchField.getText().trim().toLowerCase();
            String type = (String) searchTypeBox.getSelectedItem();
            if (!term.isEmpty()) {
                filterAppointments(term, type);
            } else {
                loadAppointments();
            }
        });

        searchPanel.add(new JLabel("Search:"));
        searchPanel.add(searchField);
        searchPanel.add(searchTypeBox);
        searchPanel.add(searchButton);
        frame.add(searchPanel, BorderLayout.SOUTH);

        JPanel inputPanel = new JPanel(new GridLayout(7, 2, 10, 10));
        inputPanel.setBackground(panelColor);
        inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(labelFont);
        nameField = new JTextField();
        nameField.setFont(fieldFont);

        JLabel dateLabel = new JLabel("Date (YYYY-MM-DD):");
        dateLabel.setFont(labelFont);
        dateField = new JTextField();
        dateField.setFont(fieldFont);

        JLabel timeLabel = new JLabel("Time (HH:MM):");
        timeLabel.setFont(labelFont);
        timeField = new JTextField();
        timeField.setFont(fieldFont);

        JLabel notesLabel = new JLabel("Notes:");
        notesLabel.setFont(labelFont);
        notesField = new JTextField();
        notesField.setFont(fieldFont);

        JButton addButton = new JButton("Add Appointment");
        addButton.setFont(labelFont);
        addButton.addActionListener(e -> {
            String name = nameField.getText().trim();
            String date = dateField.getText().trim();
            String time = timeField.getText().trim();
            String notes = notesField.getText().trim();

            if (!name.isEmpty() && !date.isEmpty() && !time.isEmpty()) {
                DatabaseHelper.insertAppointment(name, date, time, notes);
                JOptionPane.showMessageDialog(frame, "Appointment added.");
                clearFields();
                loadAppointments();
            } else {
                JOptionPane.showMessageDialog(frame, "Please fill in name, date, and time.");
            }
        });

        JButton deleteButton = new JButton("Delete Selected Appointment");
        deleteButton.setFont(labelFont);
        deleteButton.addActionListener(e -> {
            int index = appointmentList.getSelectedIndex();
            if (index >= 0 && index < currentAppointments.size()) {
                int idToDelete = currentAppointments.get(index).getId();
                DatabaseHelper.deleteAppointment(idToDelete);
                JOptionPane.showMessageDialog(frame, "Appointment deleted.");
                clearFields();
                loadAppointments();
            } else {
                JOptionPane.showMessageDialog(frame, "Select an appointment to delete.");
            }
        });

        JButton updateButton = new JButton("Update Selected Appointment");
        updateButton.setFont(labelFont);
        updateButton.addActionListener(e -> {
            if (selectedAppointmentId == -1) {
                JOptionPane.showMessageDialog(frame, "No appointment selected.");
                return;
            }

            String name = nameField.getText().trim();
            String date = dateField.getText().trim();
            String time = timeField.getText().trim();
            String notes = notesField.getText().trim();

            if (!name.isEmpty() && !date.isEmpty() && !time.isEmpty()) {
                DatabaseHelper.updateAppointment(selectedAppointmentId, name, date, time, notes);
                JOptionPane.showMessageDialog(frame, "Appointment updated.");
                clearFields();
                loadAppointments();
                selectedAppointmentId = -1;
            } else {
                JOptionPane.showMessageDialog(frame, "Please fill in all fields.");
            }
        });

        inputPanel.add(nameLabel);
        inputPanel.add(nameField);
        inputPanel.add(dateLabel);
        inputPanel.add(dateField);
        inputPanel.add(timeLabel);
        inputPanel.add(timeField);
        inputPanel.add(notesLabel);
        inputPanel.add(notesField);
        inputPanel.add(addButton);
        inputPanel.add(deleteButton);
        inputPanel.add(updateButton);
        frame.add(inputPanel, BorderLayout.NORTH);

        appointmentListModel = new DefaultListModel<>();
        appointmentList = new JList<>(appointmentListModel);
        appointmentList.addListSelectionListener(e -> {
            int index = appointmentList.getSelectedIndex();
            if (index >= 0 && index < currentAppointments.size()) {
                DatabaseAppointment appt = currentAppointments.get(index);
                nameField.setText(appt.getName());
                dateField.setText(appt.getDate());
                timeField.setText(appt.getTime());
                notesField.setText(appt.getNotes());
                selectedAppointmentId = appt.getId();
            }
        });

        frame.add(new JScrollPane(appointmentList), BorderLayout.CENTER);
        loadAppointments();
        frame.setVisible(true);
    }

    private void loadAppointments() {
        appointmentListModel.clear();
        currentAppointments = DatabaseHelper.getAppointments();
        for (DatabaseAppointment appt : currentAppointments) {
            appointmentListModel.addElement(appt.toString());
        }
    }

    private void filterAppointments(String term, String type) {
        appointmentListModel.clear();
        currentAppointments = DatabaseHelper.getAppointments();

        for (DatabaseAppointment appt : currentAppointments) {
            if (type.equals("Name") && appt.getName().toLowerCase().contains(term)) {
                appointmentListModel.addElement(appt.toString());
            } else if (type.equals("Date") && appt.getDate().toLowerCase().contains(term)) {
                appointmentListModel.addElement(appt.toString());
            }
        }
    }

    private void clearFields() {
        nameField.setText("");
        dateField.setText("");
        timeField.setText("");
        notesField.setText("");
        selectedAppointmentId = -1;
    }

    public static void main(String[] args) {
        new AppointmentManagerGUI();
    }
}
