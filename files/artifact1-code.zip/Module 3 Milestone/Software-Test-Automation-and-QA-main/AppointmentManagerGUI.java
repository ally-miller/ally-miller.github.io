import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;


public class AppointmentManagerGUI {

    private JFrame frame;
    private DefaultListModel<String> appointmentListModel;
    private JList<String> appointmentList;
    private JTextField nameField, dateField, timeField, notesField;

    private ArrayList<Appointment> appointments;

    public AppointmentManagerGUI() {
        appointments = new ArrayList<>();

        frame = new JFrame("Appointment Manager");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLayout(new BorderLayout());

        // list panel
        appointmentListModel = new DefaultListModel<>();
        appointmentList = new JList<>(appointmentListModel);
        JScrollPane listScrollPane = new JScrollPane(appointmentList);
        frame.add(listScrollPane, BorderLayout.CENTER);

        // input panel
        JPanel inputPanel = new JPanel(new GridLayout(5, 2));
        inputPanel.add(new JLabel("Name:"));
        nameField = new JTextField();
        inputPanel.add(nameField);

        inputPanel.add(new JLabel("Date (YYYY-MM-DD):"));
        dateField = new JTextField();
        inputPanel.add(dateField);

        inputPanel.add(new JLabel("Time (HH:MM):"));
        timeField = new JTextField();
        inputPanel.add(timeField);

        inputPanel.add(new JLabel("Notes:"));
        notesField = new JTextField();
        inputPanel.add(notesField);

        frame.add(inputPanel, BorderLayout.NORTH);

        // button panel
        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add");
        JButton deleteButton = new JButton("Delete");

        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);

        frame.add(buttonPanel, BorderLayout.SOUTH);

        // event listeners
        addButton.addActionListener(e -> addAppointment());
        deleteButton.addActionListener(e -> deleteAppointment());

        frame.setVisible(true);
    }

    private void addAppointment() {
        String name = nameField.getText();
        String date = dateField.getText();
        String time = timeField.getText();
        String notes = notesField.getText();

        if (!name.isEmpty() && !date.isEmpty() && !time.isEmpty()) {
            Appointment appointment = new Appointment(name, date, time, notes); // Assumes appropriate constructor
            appointments.add(appointment);
            appointmentListModel.addElement(appointment.toString());
            clearFields();
        } else {
            JOptionPane.showMessageDialog(frame, "Please fill in all required fields");
        }
    }

    private void deleteAppointment() {
        int selectedIndex = appointmentList.getSelectedIndex();
        if (selectedIndex != -1) {
            appointments.remove(selectedIndex);
            appointmentListModel.remove(selectedIndex);
        }
    }

    private void clearFields() {
        nameField.setText("");
        dateField.setText("");
        timeField.setText("");
        notesField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                new AppointmentManagerGUI();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

}
