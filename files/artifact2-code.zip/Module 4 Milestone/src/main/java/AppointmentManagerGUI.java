import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;


public class AppointmentManagerGUI {

    private JFrame frame;
    private DefaultListModel<String> appointmentListModel;
    private JList<String> appointmentList;
    private JTextField nameField, dateField, timeField, notesField;
    private JTextField searchField;
    private JComboBox<String> searchTypeBox;

    private ArrayList<Appointment> appointments;

    public AppointmentManagerGUI() {
        appointments = new ArrayList<>();

        frame = new JFrame("Appointment Manager");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());

        //font and color upgrade
        Font labelFont = new Font("SansSerif", Font.BOLD, 14);
        Font fieldFont = new Font("SansSerif", Font.PLAIN, 13);
        Color backgroundColor = new Color(245, 245, 245);
        Color panelColor = new Color(220, 235, 245);
        Color buttonColor = new Color(100, 149, 237);

        // list panel
        appointmentListModel = new DefaultListModel<>();
        appointmentList = new JList<>(appointmentListModel);
        appointmentList.setFont(fieldFont);
        JScrollPane listScrollPane = new JScrollPane(appointmentList);
        frame.add(listScrollPane, BorderLayout.CENTER);

        // input panel
        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Add New Appointment"));
        inputPanel.setBackground(panelColor);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(labelFont);
        inputPanel.add(nameLabel);
        nameField = new JTextField();
        nameField.setFont(fieldFont);
        inputPanel.add(nameField);

        JLabel dateLabel = new JLabel("Date (YYYY-MM-DD):");
        dateLabel.setFont(labelFont);
        inputPanel.add(dateLabel);
        dateField = new JTextField();
        dateField.setFont(fieldFont);
        inputPanel.add(dateField);

        JLabel timeLabel = new JLabel("Time (HH:MM):");
        timeLabel.setFont(labelFont);
        inputPanel.add(timeLabel);
        timeField = new JTextField();
        timeField.setFont(fieldFont);
        inputPanel.add(timeField);

        JLabel notesLabel = new JLabel("Notes:");
        notesLabel.setFont(labelFont);
        inputPanel.add(notesLabel);
        notesField = new JTextField();
        notesField.setFont(fieldFont);
        inputPanel.add(notesField);

        frame.add(inputPanel, BorderLayout.NORTH);

        // button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(backgroundColor);

        JButton addButton = new JButton("Add");
        addButton.setFont(labelFont);
        addButton.setBackground(buttonColor);
        addButton.setForeground(Color.WHITE);
        buttonPanel.add(addButton);

        JButton deleteButton = new JButton("Delete");
        deleteButton.setFont(labelFont);
        deleteButton.setBackground(buttonColor);
        deleteButton.setForeground(Color.WHITE);
        buttonPanel.add(deleteButton);

        frame.add(buttonPanel, BorderLayout.SOUTH);

        //search pannel
        JPanel searchPanel = new JPanel();
        searchPanel.setBackground(panelColor);
        searchPanel.setBorder(BorderFactory.createTitledBorder("Search Appointments"));

        JLabel searchLabel = new JLabel("Search:");
        searchLabel.setFont(labelFont);
        searchPanel.add(searchLabel);

        searchField = new JTextField(10);
        searchField.setFont(fieldFont);
        searchPanel.add(searchField);

        searchTypeBox = new JComboBox<>(new String[]{"Name", "Date"});
        searchTypeBox.setFont(fieldFont);
        searchPanel.add(searchTypeBox);

        JButton searchButton = new JButton("Search");
        searchButton.setFont(labelFont);
        searchButton.setBackground(buttonColor);
        searchButton.setForeground(Color.WHITE);
        searchPanel.add(searchButton);

        frame.add(searchPanel, BorderLayout.WEST);

        // event listeners
        addButton.addActionListener(e -> addAppointment());
        deleteButton.addActionListener(e -> deleteAppointment());
        searchButton.addActionListener(e -> searchAppointments());

        frame.getContentPane().setBackground(backgroundColor);
        frame.setVisible(true);
    }

    private void addAppointment() {
        String name = nameField.getText();
        String date = dateField.getText();
        String time = timeField.getText();
        String notes = notesField.getText();

        if (!name.isEmpty() && !date.isEmpty() && !time.isEmpty()) {
            Appointment appointment = new Appointment(name, date, time, notes); // Assumes appropriate constructor
            appointments.add(appointment);
            appointmentListModel.addElement(appointment.toString());
            clearFields();
        } else {
            JOptionPane.showMessageDialog(frame, "Please fill in all required fields");
        }
    }

    private void deleteAppointment() {
        int selectedIndex = appointmentList.getSelectedIndex();
        if (selectedIndex != -1) {
            appointments.remove(selectedIndex);
            appointmentListModel.remove(selectedIndex);
        }
    }

    private void clearFields() {
        nameField.setText("");
        dateField.setText("");
        timeField.setText("");
        notesField.setText("");
    }

    private void searchAppointments() {
        String searchTerm = searchField.getText().trim().toLowerCase();
        String searchType = (String) searchTypeBox.getSelectedItem();
        StringBuilder results = new StringBuilder();
        boolean found = false;

        for (Appointment appt : appointments) {
            if ("Name".equals(searchType) && appt.getName().toLowerCase().contains(searchTerm)) {
                results.append(appt.toString()).append("\n");
                found = true;
            } else if ("Date".equals(searchType) && appt.getDate().toLowerCase().contains(searchTerm)) {
                results.append(appt.toString()).append("\n");
                found = true;
            }
        }

        if (found) {
            JOptionPane.showMessageDialog(frame, results.toString(), "Search Results", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(frame, "No matching appointments found.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AppointmentManagerGUI());
    }
}
